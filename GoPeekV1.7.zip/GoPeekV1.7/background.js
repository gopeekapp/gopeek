chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "fetchLinkData") {
    
    // Fetch the raw HTML of the link behind the scenes
    fetch(request.url)
      .then(response => {
        if (!response.ok) throw new Error("Network response was not ok");
        return response.text(); // Get raw HTML text
      })
      .then(html => {
        sendResponse({ success: true, html: html });
      })
      .catch(error => {
        sendResponse({ success: false, error: error.message });
      });

    return true; // Keep the message channel open for async response
  }
});